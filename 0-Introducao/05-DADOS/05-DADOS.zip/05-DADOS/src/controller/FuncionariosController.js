app.controller('FuncionariosController', function($scope) {

	$scope.funcionarios = [
		{nome: 'Manuela'},
		{nome: 'Mariana'},
		{nome: 'Maria'}
	];

	$scope.mostra = true;
});